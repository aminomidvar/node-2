const express = require('express');
const jwt = require('jsonwebtoken');
const session = require('express-session');

const customer_routes = require('./router/auth_users.js').authenticated;
const genl_routes = require('./router/general.js').general;
const books = require('./router/booksdb.js'); // Import books directly
const auth_users = require('./router/auth_users.js'); // ✅ Fix import
const app = express();

// Middleware
app.use(express.json());
app.use(session({ secret: "fingerprint_customer", resave: true, saveUninitialized: true }));

// Authentication Middleware
app.use("/customer/auth/*", function auth(req, res, next) {
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) return res.status(401).json({ message: 'Unauthorized access' });

    jwt.verify(token, 'your-secret-key', (err, decoded) => {
        if (err) return res.status(401).json({ message: 'Invalid token' });
        req.user = decoded;
        next();
    });
});

// Route to get all books
app.get('/', (req, res) => {
    res.json({ success: true, data: books });
});

// Route to get a specific book by ID
app.get('/books/:id', (req, res) => {
    const bookId = req.params.id;
    if (books[bookId]) {
        res.json({ success: true, data: books[bookId] });
    } else {
        res.status(404).json({ success: false, message: 'Book not found' });
    }
});
// Route to get book details by ISBN
app.get('/isbn/:isbn', function (req, res) {
    const isbn = req.params.isbn; // Retrieve ISBN from request
    const book = Object.values(books).find(b => b.isbn === isbn); // Search for matching ISBN

    if (book) {
        res.json({ success: true, data: book }); // Send book details
    } else {
        res.status(404).json({ message: 'Book not found' }); // Send a 404 response
    }
});


// Route to get book details by author
app.get('/author/:author', function (req, res) {
    const author = req.params.author; // Retrieve author from request
    const book = Object.values(books).find(b => b.author === author); // Search for matching author

    if (book) {
        res.json({ success: true, data: book }); // Send book details
    } else {
        res.status(404).json({ message: 'Book not found' }); // Send a 404 response
    }
});

// Route to get book details by title
app.get('/title/:title', function (req, res) {
    const title = req.params.title; // Retrieve title from request
    const book = Object.values(books).find(b => b.title === title); // Search for matching title

    if (book) {
        res.json({ success: true, data: book }); // Send book details
    } else {
        res.status(404).json({ message: 'Book not found' }); // Send a 404 response
    }
});


// Route to get book details by review
app.get('/review/:review', function (req, res) {
    const review = req.params.review; // Retrieve review from request
    const filteredBooks = Object.values(books).filter(b => b.reviews === review); // Find matching books

    if (filteredBooks.length > 0) {
        res.json({ success: true, data: filteredBooks }); // Send books with matching reviews
    } else {
        res.status(404).json({ message: 'No books found with this review rating' }); // Send a 404 response
    }
});

// Route to register a new user
app.post('/register', (req, res) => {
    const { username, password } = req.body;

    // Check if username and password are provided
    if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
    }

    // Check if username already exists
    if (auth_users.users.find(user => user.username === username)) {
        return res.status(409).json({ message: "Username already exists" });
    }

    // Register the new user
    auth_users.users.push({ username, password });
    res.status(201).json({ message: "User registered successfully" });
});


// Route to log in as a registered customer
app.post('/customer/login', (req, res) => {
    const { username, password } = req.body;

    // Validate input
    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
    }

    // Check if user exists
    const user = auth_users.users.find(u => u.username === username && u.password === password);
    if (!user) {
        return res.status(401).json({ message: 'Invalid username or password' });
    }

    // Generate JWT token
    const token = jwt.sign({ username }, 'your-secret-key', { expiresIn: '1h' });

    // Save token in session
    req.session.token = token;

    res.status(200).json({ message: 'Login successful', token });
});

app.get("/books", (req, res) => {
    res.json({ success: true, data: books });
});
const PORT = 5000;

// Route Setup
app.use("/customer", customer_routes);
app.use("/", genl_routes);

app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));