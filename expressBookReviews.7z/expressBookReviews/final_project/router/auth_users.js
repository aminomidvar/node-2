const express = require("express");
const jwt = require("jsonwebtoken");
let books = require("./booksdb.js"); // Import books database
const regd_users = express.Router();

let users = [];

// ✅ Check if username exists
const isValid = (username) => {
    return users.some(user => user.username === username);
};

// ✅ Authenticate user credentials
const authenticatedUser = (username, password) => {
    return users.some(user => user.username === username && user.password === password);
};

// ✅ Get all registered users
regd_users.get("/users", (req, res) => {
    res.json({ users });
});

// ✅ Login Route for Registered Users
regd_users.post("/login", (req, res) => {
    const { username, password } = req.body;

    // Validate input
    if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
    }

    // Check if user exists
    if (!authenticatedUser(username, password)) {
        return res.status(401).json({ message: "Invalid username or password" });
    }

    // Generate JWT token
    const token = jwt.sign({ username }, "your-secret-key", { expiresIn: "1h" });

    // Save token in session
    req.session.token = token;

    res.status(200).json({ message: "Login successful", token });
});

// ✅ Authentication Middleware (Ensure user is logged in before adding/modifying reviews)
const authenticateToken = (req, res, next) => {
    const token = req.headers.authorization?.split(" ")[1];

    if (!token) {
        return res.status(401).json({ message: "Unauthorized access" });
    }

    jwt.verify(token, "your-secret-key", (err, decoded) => {
        if (err) {
            return res.status(401).json({ message: "Invalid token" });
        }
        req.user = decoded;
        next();
    });
};

// ✅ Random Review Options
const randomReviews = ["good", "bad", "very good", "excellent", "poor", "average"];
const getRandomReview = () => randomReviews[Math.floor(Math.random() * randomReviews.length)];

// ✅ Add or Modify Book Reviews
regd_users.put("/auth/review/:isbn", authenticateToken, (req, res) => {
    const isbn = req.params.isbn;
    const review = req.query.review || getRandomReview(); // Use provided review or assign random
    const username = req.user.username;

    // Find the book using ISBN
    const book = Object.values(books).find(b => b.isbn === isbn);

    if (!book) {
        return res.status(404).json({ message: "Book not found." });
    }

    // ✅ Modify or add review
    if (book.reviews[username]) {
        book.reviews[username] = review;
        res.json({ message: "Review updated successfully.", data: book.reviews });
    } else {
        book.reviews[username] = review;
        res.json({ message: "Review added successfully.", data: book.reviews });
    }
});

regd_users.delete("/auth/review/:isbn", authenticateToken, (req, res) => {
    const isbn = req.params.isbn;
    const username = req.user.username; // Get username from JWT session

    // Find the book using ISBN
    const book = Object.values(books).find((b) => b.isbn === isbn);

    if (!book) {
        return res.status(404).json({ message: "Book not found." });
    }

    // Check if the user has a review for this book
    if (!book.reviews[username]) {
        return res.status(404).json({ message: "Review not found or you are not the owner." });
    }

    // Delete the user's review
    delete book.reviews[username];

    res.json({ message: "Review deleted successfully.", data: book.reviews });
});

// ✅ Corrected module exports
module.exports.authenticated = regd_users;
module.exports.authenticatedUser = authenticatedUser;
module.exports.isValid = isValid;
module.exports.users = users;