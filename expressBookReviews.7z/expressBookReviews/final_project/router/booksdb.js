let books = {
    "978-0385474542": { 
        author: "Chinua Achebe", 
        title: "Things Fall Apart", 
        reviews: {} 
    },
    "978-0140449013": { 
        author: "Hans Christian Andersen", 
        title: "Fairy tales", 
        reviews: {} 
    },
    "978-0199535644": { 
        author: "Dante Alighieri", 
        title: "The Divine Comedy", 
        reviews: {} 
    },
    "978-0140449198": { 
        author: "Unknown", 
        title: "The Epic Of Gilgamesh", 
        reviews: {} 
    },
    "978-0140449129": { 
        author: "Unknown", 
        title: "The Book Of Job", 
        reviews: {} 
    },
    "978-0140449389": { 
        author: "Unknown", 
        title: "One Thousand and One Nights", 
        reviews: {} 
    },
    "978-0140447699": { 
        author: "Unknown", 
        title: "Njál's Saga", 
        reviews: {} 
    },
    "978-0141439518": { 
        author: "Jane Austen", 
        title: "Pride and Prejudice", 
        reviews: {} 
    },
    "978-0140449723": { 
        author: "Honoré de Balzac", 
        title: "Le Père Goriot", 
        reviews: {} 
    },
    "978-0802144478": { 
        author: "Samuel Beckett", 
        title: "Molloy, Malone Dies, The Unnamable, the trilogy", 
        reviews: {} 
    }
};

module.exports = books;