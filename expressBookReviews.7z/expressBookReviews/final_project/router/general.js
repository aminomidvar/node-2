const express = require("express");
const axios = require("axios");
let books = require("./booksdb.js"); // Import books database

const public_users = express.Router();

// ✅ Get book details by Title using Async/Await with Axios
public_users.get("/title/:title", async (req, res) => {
    try {
        const title = req.params.title;
        const response = await axios.get("http://localhost:5000/books");
        const booksData = response.data.data;

        const filteredBooks = Object.values(booksData).filter(book => book.title === title);

        if (filteredBooks.length > 0) {
            res.status(200).json({ success: true, data: filteredBooks });
        } else {
            res.status(404).json({ success: false, message: "No books found with this title" });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: "Error fetching book details." });
    }
});

// ✅ Get book details by Title using Promises with Axios
public_users.get("/title-promise/:title", (req, res) => {
    const title = req.params.title;

    axios.get("http://localhost:5000/books")
        .then(response => {
            const booksData = response.data.data;
            const filteredBooks = Object.values(booksData).filter(book => book.title === title);

            if (filteredBooks.length > 0) {
                res.status(200).json({ success: true, data: filteredBooks });
            } else {
                res.status(404).json({ success: false, message: "No books found with this title" });
            }
        })
        .catch(error => {
            res.status(500).json({ success: false, message: "Error fetching book details." });
        });
});

module.exports.general = public_users;